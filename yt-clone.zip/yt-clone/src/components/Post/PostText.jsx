
const PostText = ({ item }) => {
  console.log(item)
  return (
    <div>PostText</div>
  )
}

export default PostText