
const ChannelDetails = () => {
  return (
    <div>ChannelDetails</div>
  )
}

export default ChannelDetails