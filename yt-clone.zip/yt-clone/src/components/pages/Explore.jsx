import { useParams } from "react-router-dom";
import Videos from "../Video/Videos";
import { useEffect, useRef, useState } from "react";
import { fetcher } from "../../utils";
import { layout } from "../../style";

const Explore = () => {
  const { category } = useParams();
  const [result, setResult] = useState({ data: [] });
  const addData = (d) => {
    setResult((pre) => ({
      ...pre,
      data: [...(pre?.data || []), ...(d?.data || [])],
    }));
  };

  useEffect(() => {
    fetcher(`search?query=${category}`).then((d) => {
      setResult(d);
    });
  }, [category]);

  return (
    <div className={`${layout.container}`}>
      <Videos data={result?.data} />
      {/* <LoadMore result={result} category={category} addData={addData} /> */}
    </div>
  );
};

export default Explore;

// const LoadMore = ({ addData, url, category }) => {
//   const [page, setPage] = useState(1);
//   const loadMoreButtonRef = useRef(null);
//   const [isVisible, setIsVisible] = useState(false);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     setLoading((_) => true);
//     if (isVisible) {
//       fetcher(url || `search?query=${category}&page=${page}`).then((res) => {
//         setLoading((_) => false);
//         addData(res);
//       });
//       setPage((p) => p + 1);
//     }
//   }, [category, isVisible]);
//   useEffect(() => {
//     const observer = new IntersectionObserver(
//       (entries) => setIsVisible(entries[0].isIntersecting),
//       { threshold: 1.0 },
//     );

//     if (loadMoreButtonRef.current) observer.observe(loadMoreButtonRef.current);

//     return () => {
//       if (loadMoreButtonRef.current)
//         observer.unobserve(loadMoreButtonRef.current);
//     };
//   }, [page]);
//   return (
//     <button ref={loadMoreButtonRef} className="mx-auto block p-6">
//       {loading && (
//         <span className="flex h-[30px]  w-[30px] animate-spin items-center  justify-center rounded-full border-2 border-slate-500 border-l-transparent">
//           {" "}
//         </span>
//       )}
//     </button>
//   );
// };
