
const ShortsListing = () => {
  return (
    <div>ShortsListing</div>
  )
}

export default ShortsListing