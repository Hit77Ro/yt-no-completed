import { BsDot } from "react-icons/bs";
import { cutText, formatViews, getImg } from "../../utils";
import styles from "../../style";
import { Link } from "react-router-dom";
import { AiFillCheckCircle } from "react-icons/ai";

const VideoCard = ({ item, direction, channelMode }) => {
  if (!item.thumbnail) return;
  const {
    videoId,
    title,
    channelTitle,
    channelId,
    channelThumbnail,
    description,
    viewCount,
    publishDate,
    publishedTimeText,
    lengthText,
    isLive,
    thumbnail,
  } = item;
  console.log(item);
  return (
    <div
      className={`${
        direction ? "grid gap-3 sm:grid-cols-[minmax(200px,300px),1.5fr]" : ""
      }`}
    >
      <div className="flex max-h-[250px]">
        <Link className="w-full" to={`/watch/${videoId}`}>
          <img
            src={getImg(thumbnail, 2)}
            alt="video thumbnail"
            className="  xs:rounded-xl"
          />
        </Link>
      </div>

      {/* Content */}
      <div className={`flex items-start  gap-2 p-2`}>
        {/* mini channel image */}
        {!direction && ChannelImg(channelThumbnail)}

        {/* video details */}

        <div className="sm:sm text-sm  text-slate-700">
          <Link
            to={`/watch/${videoId}`}
            className="text-slate-800 "
            title={title}
          >
            {cutText(title, 6)}
          </Link>
          <div
            className={`flex ${direction ? "flex-col-reverse" : "flex-col"}  `}
          >
            {!channelMode && (
              <Link
                to={`/channel/${channelId}`}
                className={`my-1 flex-wrap gap-1 text-[12px]   ${styles.centerX}`}
              >
                {direction && ChannelImg(channelThumbnail, channelId)}
                <span>{channelTitle}</span>
                <span>
                  {" "}
                  <AiFillCheckCircle />{" "}
                </span>
              </Link>
            )}
            {!isLive && (
              <Link to={`/watch/${videoId}`} className={` ${styles.centerX}`}>
                <span> {formatViews(+viewCount)} views </span>
                <BsDot />
                <span>{publishedTimeText}</span>
              </Link>
            )}
          </div>
          {item?.description && direction && (
            <p className="mt-2 text-xs"> {cutText(item?.description, 10)} </p>
          )}
        </div>
      </div>
    </div>
  );
};

const ChannelImg = (channelThumbnail, channelId) => {
  return (
    <Link to={`/channel/${channelId}`} className="shrink-0">
      <img
        src={getImg(channelThumbnail, 3)}
        alt="channel thumbnail"
        className="w-[27px] rounded-full"
      />
    </Link>
  );
};
export default VideoCard;
