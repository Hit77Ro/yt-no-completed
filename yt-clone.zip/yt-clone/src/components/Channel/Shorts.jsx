
const Shorts = () => {
  return (
    <div>Shorts</div>
  )
}

export default Shorts