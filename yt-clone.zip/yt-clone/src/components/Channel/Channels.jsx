
const Channels = () => {
  return (
    <div>Channels</div>
  )
}

export default Channels