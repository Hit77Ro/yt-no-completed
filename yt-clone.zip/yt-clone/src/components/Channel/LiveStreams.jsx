
const LiveStreams = () => {
  return (
    <div>LiveStreams</div>
  )
}

export default LiveStreams