
const Playlists = () => {
  return (
    <div>Playlists</div>
  )
}

export default Playlists