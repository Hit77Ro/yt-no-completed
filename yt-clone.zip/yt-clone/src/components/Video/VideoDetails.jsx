
const VideoDetails = () => {
  return (
    <div>VideoDetails</div>
  )
}

export default VideoDetails