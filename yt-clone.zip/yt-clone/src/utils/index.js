import { cutText  ,formatViews} from "./youtube";

export { default as Loader } from "./Loader";
export { default as Slider } from "./Slider";
export { default as useClickOutside } from "./useClickOutside";
export { default as getImg } from "./getImg";
export { default as fetcher } from "./api";

export { cutText  ,formatViews};
